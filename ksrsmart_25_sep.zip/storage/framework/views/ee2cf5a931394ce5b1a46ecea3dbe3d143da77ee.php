<?php $__env->startSection('content'); ?>

<div id="app">
	<schedule-assign :authenticateduser="<?php echo e(Auth::user()); ?>" :authrole="<?php echo e(Auth::user()->GetRole()); ?>"></schedule-assign>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>