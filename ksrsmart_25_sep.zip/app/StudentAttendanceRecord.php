<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentAttendanceRecord extends Model
{
    protected $table = 'student_attendance_records';
}
