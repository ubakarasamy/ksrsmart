<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaffApproval extends Model
{
    protected $table = 'staff_approvals';
}
