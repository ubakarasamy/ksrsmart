<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaffAttendanceDate extends Model
{
    protected $table = 'staff_attendance_dates';
}
