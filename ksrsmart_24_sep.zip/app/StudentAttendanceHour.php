<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentAttendanceHour extends Model
{
    protected $table = 'student_attendance_hours';
}
