<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaffAttendanceRecord extends Model
{
    protected $table = 'staff_attendance_records';
}
