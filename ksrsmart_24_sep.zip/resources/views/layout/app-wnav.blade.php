@include('layout.inc.header')


 @yield('content')


@include('layout.inc.footer')