@include('layout.inc.header')

@include('layout.inc.dashboard-navbar')


 @yield('content')


@include('layout.inc.footer')