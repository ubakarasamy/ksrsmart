<?php $__env->startSection('content'); ?>

<div id="app">
	<schedule-index :authenticateduser="<?php echo e(Auth::user()); ?>" :authrole="<?php echo e(Auth::user()->GetRole()); ?>"></schedule-index>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>